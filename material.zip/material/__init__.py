bl_info = {
	"name" : "Colourful Curves",
				"description" : "Can be used for creating amazing curves",
	"author" : "Vaishnav",
	"version" : (1, 0, 0),
	"blender" : (4, 2, 1),
	"location" : "Node",
	"category" : "Node",
}

import bpy
import mathutils
import os

class Material(bpy.types.Operator):
	bl_idname = "node.material"
	bl_label = "Material"
	bl_options = {'REGISTER', 'UNDO'}
			
	def execute(self, context):
		mat = bpy.data.materials.new(name = "Material")
		mat.use_nodes = True
		#initialize Material node group
		def material_node_group():

			material = mat.node_tree
			#start with a clean node tree
			for node in material.nodes:
				material.nodes.remove(node)
			material.color_tag = 'NONE'
			material.description = ""

			#material interface
			
			#initialize material nodes
			#node Principled BSDF
			principled_bsdf = material.nodes.new("ShaderNodeBsdfPrincipled")
			principled_bsdf.name = "Principled BSDF"
			principled_bsdf.distribution = 'MULTI_GGX'
			principled_bsdf.subsurface_method = 'RANDOM_WALK'
			#Metallic
			principled_bsdf.inputs[1].default_value = 0.0
			#Roughness
			principled_bsdf.inputs[2].default_value = 0.5
			#IOR
			principled_bsdf.inputs[3].default_value = 1.5
			#Alpha
			principled_bsdf.inputs[4].default_value = 1.0
			#Normal
			principled_bsdf.inputs[5].default_value = (0.0, 0.0, 0.0)
			#Subsurface Weight
			principled_bsdf.inputs[7].default_value = 0.0
			#Subsurface Radius
			principled_bsdf.inputs[8].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
			#Subsurface Scale
			principled_bsdf.inputs[9].default_value = 0.05000000074505806
			#Subsurface Anisotropy
			principled_bsdf.inputs[11].default_value = 0.0
			#Specular IOR Level
			principled_bsdf.inputs[12].default_value = 0.5
			#Specular Tint
			principled_bsdf.inputs[13].default_value = (1.0, 1.0, 1.0, 1.0)
			#Anisotropic
			principled_bsdf.inputs[14].default_value = 0.0
			#Anisotropic Rotation
			principled_bsdf.inputs[15].default_value = 0.0
			#Tangent
			principled_bsdf.inputs[16].default_value = (0.0, 0.0, 0.0)
			#Transmission Weight
			principled_bsdf.inputs[17].default_value = 0.0
			#Coat Weight
			principled_bsdf.inputs[18].default_value = 0.0
			#Coat Roughness
			principled_bsdf.inputs[19].default_value = 0.029999999329447746
			#Coat IOR
			principled_bsdf.inputs[20].default_value = 1.5
			#Coat Tint
			principled_bsdf.inputs[21].default_value = (1.0, 1.0, 1.0, 1.0)
			#Coat Normal
			principled_bsdf.inputs[22].default_value = (0.0, 0.0, 0.0)
			#Sheen Weight
			principled_bsdf.inputs[23].default_value = 0.0
			#Sheen Roughness
			principled_bsdf.inputs[24].default_value = 0.5
			#Sheen Tint
			principled_bsdf.inputs[25].default_value = (1.0, 1.0, 1.0, 1.0)
			#Emission Color
			principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
			#Emission Strength
			principled_bsdf.inputs[27].default_value = 0.0
			#Thin Film Thickness
			principled_bsdf.inputs[28].default_value = 0.0
			#Thin Film IOR
			principled_bsdf.inputs[29].default_value = 1.3300000429153442
			
			#node Material Output
			material_output = material.nodes.new("ShaderNodeOutputMaterial")
			material_output.name = "Material Output"
			material_output.is_active_output = True
			material_output.target = 'ALL'
			#Displacement
			material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
			#Thickness
			material_output.inputs[3].default_value = 0.0
			
			#node Attribute
			attribute = material.nodes.new("ShaderNodeAttribute")
			attribute.name = "Attribute"
			attribute.attribute_name = "S"
			attribute.attribute_type = 'GEOMETRY'
			
			#node Hue/Saturation/Value
			hue_saturation_value = material.nodes.new("ShaderNodeHueSaturation")
			hue_saturation_value.name = "Hue/Saturation/Value"
			#Saturation
			hue_saturation_value.inputs[1].default_value = 1.0
			#Value
			hue_saturation_value.inputs[2].default_value = 1.0
			#Fac
			hue_saturation_value.inputs[3].default_value = 1.0
			#Color
			hue_saturation_value.inputs[4].default_value = (0.36062121391296387, 0.0, 0.8084508180618286, 1.0)
			
			
			#Set locations
			principled_bsdf.location = (60.302955627441406, 305.8802185058594)
			material_output.location = (443.637939453125, 317.6407165527344)
			attribute.location = (-374.46026611328125, 300.20648193359375)
			hue_saturation_value.location = (-134.99998474121094, 321.37530517578125)
			
			#Set dimensions
			principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
			material_output.width, material_output.height = 140.0, 100.0
			attribute.width, attribute.height = 140.0, 100.0
			hue_saturation_value.width, hue_saturation_value.height = 150.0, 100.0
			
			#initialize material links
			#attribute.Fac -> hue_saturation_value.Hue
			material.links.new(attribute.outputs[2], hue_saturation_value.inputs[0])
			#hue_saturation_value.Color -> principled_bsdf.Base Color
			material.links.new(hue_saturation_value.outputs[0], principled_bsdf.inputs[0])
			#hue_saturation_value.Color -> material_output.Surface
			material.links.new(hue_saturation_value.outputs[0], material_output.inputs[0])
			return material

		material = material_node_group()

		return {'FINISHED'}
def menu_func(self, context):
	self.layout.operator(Material.bl_idname)
			
def register():
	bpy.utils.register_class(Material)
	bpy.types.NODE_MT_add.append(menu_func)
			
def unregister():
	bpy.utils.unregister_class(Material)
	bpy.types.NODE_MT_add.remove(menu_func)
			
if __name__ == "__main__":
	register()
